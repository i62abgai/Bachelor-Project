# BachelorProject
Implementation of SVM in python
